﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmview_return

	'Using Metro Framework
	Inherits MetroFramework.Forms.MetroForm

	'Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
	Private Sub InitializeComponent()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.txtsearch = New System.Windows.Forms.TextBox()
		Me.dtglist = New System.Windows.Forms.DataGridView()
		CType(Me.dtglist, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Georgia", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(150, 60)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(309, 34)
		Me.Label2.TabIndex = 18
		Me.Label2.Text = "List Of Stock Returned"
		'
		'Label1
		'
		Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(271, 125)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(47, 13)
		Me.Label1.TabIndex = 17
		Me.Label1.Text = "Search: "
		'
		'txtsearch
		'
		Me.txtsearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtsearch.Location = New System.Drawing.Point(324, 122)
		Me.txtsearch.Name = "txtsearch"
		Me.txtsearch.Size = New System.Drawing.Size(312, 20)
		Me.txtsearch.TabIndex = 16
		'
		'dtglist
		'
		Me.dtglist.AllowUserToAddRows = False
		Me.dtglist.AllowUserToDeleteRows = False
		Me.dtglist.AllowUserToResizeColumns = False
		Me.dtglist.AllowUserToResizeRows = False
		Me.dtglist.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.dtglist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
		Me.dtglist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.dtglist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.dtglist.Location = New System.Drawing.Point(23, 159)
		Me.dtglist.Name = "dtglist"
		Me.dtglist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.dtglist.Size = New System.Drawing.Size(613, 304)
		Me.dtglist.TabIndex = 15
		'
		'frmview_return
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(659, 486)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.txtsearch)
		Me.Controls.Add(Me.dtglist)
		Me.Name = "frmview_return"
		Me.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow
		Me.Style = MetroFramework.MetroColorStyle.Green
		Me.Text = "View Return"
		CType(Me.dtglist, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Label2 As Label
	Friend WithEvents Label1 As Label
	Friend WithEvents txtsearch As TextBox
	Friend WithEvents dtglist As DataGridView
End Class
